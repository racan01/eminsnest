resource_type 'map' { gameTypes = { fs_freeroam = true } }

map 'map.lua'
