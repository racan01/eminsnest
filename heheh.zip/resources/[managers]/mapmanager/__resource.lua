client_scripts {
    "mapmanager_client.lua",
    "mapmanager_shared.lua"
}

server_scripts {
    "mapmanager_server.lua",
    "mapmanager_shared.lua"
}
